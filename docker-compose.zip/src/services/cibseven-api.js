import { axios } from '@cibseven/plugin-runtime'

export async function getProcessInstance(processInstanceId) {
  if (!processInstanceId) {
    throw new Error('processInstanceId is required')
  }

  const response = await axios.get(
    `/engine-rest/process-instance/${encodeURIComponent(processInstanceId)}`
  )

  return response.data
}