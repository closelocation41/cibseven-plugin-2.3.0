import MyPlugin from './MyPlugin.vue'

export function register({ id, registerPlugin }) {
  registerPlugin('process-instance-tab', MyPlugin, {
    id: 'my-plugin-tab',
    text: `plugins.${id}.title`
  })
}