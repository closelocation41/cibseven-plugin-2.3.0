<template>
  <div class="my-plugin p-3">
    <div class="d-flex justify-content-between align-items-center mb-3">
      <h4 class="mb-0">{{ title }}</h4>
      <span class="badge text-bg-primary">CIB seven 2.3</span>
    </div>

    <div class="card mb-3">
      <div class="card-header">Process Instance</div>
      <div class="card-body">
        <dl class="row mb-0">
          <dt class="col-sm-3">ID</dt>
          <dd class="col-sm-9">{{ instanceId || '-' }}</dd>

          <dt class="col-sm-3">Definition Key</dt>
          <dd class="col-sm-9">{{ process?.key || '-' }}</dd>

          <dt class="col-sm-3">Definition ID</dt>
          <dd class="col-sm-9">{{ process?.id || '-' }}</dd>

          <dt class="col-sm-3">Business Key</dt>
          <dd class="col-sm-9">{{ instance?.businessKey || '-' }}</dd>

          <dt class="col-sm-3">Tenant</dt>
          <dd class="col-sm-9">{{ tenantId || instance?.tenantId || '-' }}</dd>
        </dl>
      </div>
    </div>

    <button
      class="btn btn-primary"
      :disabled="loading || !instanceId"
      @click="loadProcessInformation"
    >
      <span v-if="loading" class="spinner-border spinner-border-sm me-2"></span>
      {{ loading ? 'Loading...' : 'Load Process Information' }}
    </button>

    <div v-if="error" class="alert alert-danger mt-3 mb-0">
      {{ error }}
    </div>

    <div v-if="response" class="card mt-3">
      <div class="card-header">API Response</div>
      <div class="card-body">
        <pre class="api-response mb-0">{{ formattedResponse }}</pre>
      </div>
    </div>
  </div>
</template>

<script setup>
import { computed, ref } from 'vue'
import { getProcessInstance } from './services/cibseven-api.js'

const props = defineProps({
  instance: {
    type: Object,
    required: true
  },
  process: {
    type: Object,
    default: null
  },
  tenantId: {
    type: String,
    default: null
  }
})

const title = 'My CIB seven Plugin'
const loading = ref(false)
const error = ref('')
const response = ref(null)

const instanceId = computed(() => props.instance?.id || '')

const formattedResponse = computed(() =>
  JSON.stringify(response.value, null, 2)
)

async function loadProcessInformation() {
  loading.value = true
  error.value = ''
  response.value = null

  try {
    response.value = await getProcessInstance(instanceId.value)
  } catch (err) {
    console.error('CIB seven process-instance request failed:', err)

    const status = err?.response?.status
    if (status === 401) {
      error.value = 'Unable to load process information. Authentication is required (401).'
    } else if (status === 403) {
      error.value = 'Unable to load process information. You do not have permission (403).'
    } else if (status === 404) {
      error.value = 'Unable to load process information. Process instance was not found (404).'
    } else if (status >= 500) {
      error.value = 'Unable to load process information. Server error (500).'
    } else {
      error.value = 'Unable to load process information.'
    }
  } finally {
    loading.value = false
  }
}
</script>