import { rm } from 'node:fs/promises'

await Promise.all([
  rm('dist', { recursive: true, force: true }),
  rm('my-plugin.jar', { force: true })
])

console.log('Clean complete')