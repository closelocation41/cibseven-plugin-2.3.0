import { existsSync } from 'node:fs'
import { mkdir, rm } from 'node:fs/promises'
import { spawnSync } from 'node:child_process'

const dist = 'dist'
const jar = 'my-plugin.jar'

if (!existsSync(`${dist}/META-INF/cibseven-plugins/my-plugin/plugin.json`)) {
  console.error('Build output not found. Run: npm run build')
  process.exit(1)
}

await rm(jar, { force: true })

const result = spawnSync(
  'jar',
  ['--create', '--file', jar, '-C', dist, 'META-INF'],
  { stdio: 'inherit', shell: process.platform === 'win32' }
)

if (result.status !== 0) {
  console.error('JAR creation failed. Install a JDK and ensure the jar command is on PATH.')
  process.exit(result.status ?? 1)
}

console.log(`Created ${jar}`)